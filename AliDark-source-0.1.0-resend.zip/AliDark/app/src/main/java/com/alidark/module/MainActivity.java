package com.alidark.module;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("AliDark 0.1.0");
        title.setTextSize(24);
        root.addView(title);

        TextView body = new TextView(this);
        body.setText("本模块为早期适配版。\n\n支持目标：美团、支付宝、闲鱼、淘宝。\n模式：跟随系统深色/浅色。\n\n安装后请在 LSPosed 中启用模块，并仅勾选四个目标应用，然后重启这四个应用。\n\n注意：Force Dark 只能处理 Android 可自动转换的 View 和部分 WebView。应用自绘页面、Flutter/自研渲染页面及部分图片/弹窗可能仍是浅色，需逐个版本适配。");
        body.setTextSize(16);
        body.setPadding(0, pad, 0, 0);
        root.addView(body);
        setContentView(root);
    }
}
