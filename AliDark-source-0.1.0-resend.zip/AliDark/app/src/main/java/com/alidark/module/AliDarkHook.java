package com.alidark.module;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * AliDark prototype: asks Android's native Force Dark implementation and WebView
 * to follow the host application's current system night mode.
 *
 * Important: this does not rewrite proprietary/custom drawing code inside target apps.
 */
public final class AliDarkHook implements IXposedHookLoadPackage {
    private static final String TAG = "[AliDark] ";

    private static final String[] TARGET_PACKAGES = new String[] {
            "com.sankuai.meituan",
            "com.eg.android.AlipayGphone",
            "com.taobao.idlefish",
            "com.taobao.taobao"
    };

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!isTarget(lpparam.packageName)) return;

        XposedBridge.log(TAG + "loaded for " + lpparam.packageName);

        hookActivityResume(lpparam);
        hookWebViewAttach(lpparam);
    }

    private static boolean isTarget(String packageName) {
        for (String target : TARGET_PACKAGES) {
            if (target.equals(packageName)) return true;
        }
        return false;
    }

    private static void hookActivityResume(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Activity activity = (Activity) param.thisObject;
                        applyToActivity(activity);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "Activity apply failed: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "Activity hook failed: " + t);
        }
    }

    private static void applyToActivity(Activity activity) {
        if (activity == null || Build.VERSION.SDK_INT < 29) return;
        try {
            // FORCE_DARK_ALLOWED lets Android's automatic Force Dark algorithm
            // transform eligible light-themed Views when the system is in dark mode.
            View decor = activity.getWindow() != null
                    ? activity.getWindow().getDecorView() : null;
            if (decor != null) {
                decor.setForceDarkAllowed(true);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setForceDarkAllowed failed: " + t);
        }
    }

    private static void hookWebViewAttach(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(WebView.class, "onAttachedToWindow",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                WebView webView = (WebView) param.thisObject;
                                applyToWebView(webView);
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + "WebView apply failed: " + t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "WebView hook failed: " + t);
        }
    }

    private static void applyToWebView(WebView webView) {
        if (webView == null || Build.VERSION.SDK_INT < 29) return;
        try {
            WebSettings settings = webView.getSettings();
            if (settings != null) {
                // AUTO follows the host app's current system/theme night mode;
                // it does not force dark content while the phone is in light mode.
                settings.setForceDark(WebSettings.FORCE_DARK_AUTO);
                if (Build.VERSION.SDK_INT >= 29) {
                    settings.setForceDarkStrategy(
                            WebSettings.FORCE_DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "WebView settings failed: " + t);
        }
    }
}
